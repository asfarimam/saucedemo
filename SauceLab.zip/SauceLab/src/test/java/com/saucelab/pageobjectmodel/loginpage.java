package com.saucelab.pageobjectmodel;

import org.openqa.selenium.By;

import com.saucelab.TestCases.BaseClass;

public class loginpage extends BaseClass {

//define Locators
	private By usernameInput = By.id("user-name");
	private By passwordInput = By.id("password");
	private By loginButton = By.id("login-button");
	private By errorMessage = By.xpath("//h3[contains(text(),'Epic sadface: Username and password do not match a')]");
	// private By errorMessage = By.id("error-message");

	public void Login(String url, String username, String password) {
		try {
			Thread.sleep(2000);
			driver.navigate().to(url);

			// logger.info("url is : " + url);
			Thread.sleep(2000);
			driver.findElement(usernameInput).sendKeys(username);
			// log.Info("username is : " + username);
			Thread.sleep(2000);
			driver.findElement(passwordInput).sendKeys(password);
			// log.Info("password is : " + password);
			Thread.sleep(2000);
			driver.findElement(loginButton).click();
			Thread.sleep(2000);
		}

		catch (Exception ex) {

			System.out.println("Something Went Wrong");
			// log.Error("Login Failed " + ex);
		}
	}

	public String getErrorMessage() {
		return driver.findElement(errorMessage).getText();
	}
}