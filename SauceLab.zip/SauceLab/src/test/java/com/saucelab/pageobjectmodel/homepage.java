package com.saucelab.pageobjectmodel;

import org.openqa.selenium.By;
import com.saucelab.TestCases.BaseClass;

public class homepage extends BaseClass {
	// define Locators
	private By menuOpt = By.xpath("//button[@id='react-burger-menu-btn']");
	private By logOut = By.xpath("//a[@id='logout_sidebar_link']");
	private By addcartbackpack = By.id("add-to-cart-sauce-labs-backpack");
	private By cartbadge = By.xpath("//span[@class='shopping_cart_badge']");
	private By yourcart = By.xpath("//a[@class='shopping_cart_link']");
	private By cartitems = By.xpath("//div[@class='cart_item']");
	private By checkout = By.xpath("//button[@id='checkout']");
	private By fname = By.xpath("//input[@id='first-name']");
	private By lname = By.xpath("//input[@id='last-name']");
	private By zipcode = By.xpath("//input[@id='postal-code']");
	private By yourinfoerror = By.xpath("//div[@class='error-message-container error']");
	private By continueBTN = By.xpath("//input[@id='continue']");
	private By finishBTN = By.xpath("//button[@id='finish']");
	private By total = By.xpath("//div[@class='summary_info_label summary_total_label']");
	private By thanksMsg = By.xpath("//h2[normalize-space()='Thank you for your order!']");
	private By backtoproduct = By.xpath("//button[@id='back-to-products']");
	private By removeBTN = By.xpath("//button[@id='remove-sauce-labs-backpack']");


	public void LogoutUser() {
		try {
			Thread.sleep(2500);
			driver.findElement(menuOpt).click();
			Thread.sleep(4000);
			driver.findElement(logOut).click();
			Thread.sleep(10000);
		} catch (Exception e) {
			System.out.println("LogOut Failed Something Went Wrong Please see the Logs: " + e);
		}
	}

	public void addtocart() {
		try {
			// adding item to cart i.e backpack
			driver.findElement(addcartbackpack).click();
			Thread.sleep(2000);
			// finding element after addtocart that badge icon is visible and show no.of item
			driver.findElement(cartbadge);
		
			if (cartbadge != null) {
				System.out.println("Item has beed added to cart successfully :  ");
			} else {
				System.out.println("Item not added in cart something went wrong :  ");
			}
		} catch (Exception e) {
			System.out.println("Add to cart not functioning Something Went Wrong Please see the Logs: " + e);
		}
	}
	
	public void carthasitem() {
		try {
			// navigate to your cart page
			driver.findElement(yourcart).click();
			// validate if cart has any item or not
			driver.findElement(cartitems);
			if (cartitems!= null) {
				System.out.println("cart has items :  ");
			} else {
				System.out.println(
				"There is No item in your cart please continue shopping and add item to to your cart :  ");
			}
		} catch (Exception e) {
			System.out.println("Something Went Wrong Please see the Logs: " + e);
		}
	}
	
	public void checkout() {
		try {
			Thread.sleep(3000);
			// click on check out button
			driver.findElement(checkout).click();
			// enter details for checkout
			Thread.sleep(3000);
			driver.findElement(fname).sendKeys("asfar");
			driver.findElement(lname).sendKeys("test");
			driver.findElement(zipcode).sendKeys("42101");
			Thread.sleep(2000);
			// click to navigate checkout overview page
			driver.findElement(continueBTN).click();

			Thread.sleep(3000);
		} catch (Exception e) {
			System.out.println("Something Went Wrong Please see the Logs: " + e);
		}	
	}

	public String getErrorMessageyourinfo() {
		// get error msg on your Info page
		return driver.findElement(yourinfoerror).getText();
	}
	
	public void gettotal() {
		// get total on payment page i.e overview page
		String gettotal = driver.findElement(total).getText();
		System.out.println("Success Message: " + gettotal);
	}
	
	public void getsuccessMessage() {
		// get total on payment page i.e overview page
		String getsuccessmsg =  driver.findElement(thanksMsg).getText();
		System.out.println("Success Message: " + getsuccessmsg);
	}
	
	public void clickbacktoproduct() {
		// navigate back to product page
		driver.findElement(backtoproduct).click();
	}
	
	public void clickfinish() {
		// click on finish button
		driver.findElement(finishBTN).click();
	}
	public void removefromcart() {
		try {
			// navigate to your cart page
			driver.findElement(yourcart).click();
			Thread.sleep(4000);

			driver.findElement(removeBTN);
		

			if (removeBTN != null) {
				driver.findElement(removeBTN).click();
				System.out.println("Item has removed from Cart :  ");
				Thread.sleep(2000);
			} else {
				System.out.println("No Item in Cart to Remove :  ");
			}
		} catch (Exception e) {
			System.out.println("Something Went Wrong Please see the Logs: " + e);
		}

	}
	
}