package com.saucelab.TestCases;

import java.io.File;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class BaseClass {

	public static WebDriver driver;
	public static ExtentReports extent;
	public static ExtentSparkReporter spark;
	public static ExtentTest exParentTest;
	public static ExtentTest exChildTest;
	public static TakesScreenshot scrShot;

	public static void launchbrowser() {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "//Drivers//chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--start-maximized");
		options.addArguments("allow-file-access-from-files");
		options.addArguments("use-fake-ui-for-media-stream");
		// options.AddArgument("ignore-certificate-errors");
		// options.AddArguments("disable-popup-blocking");
		driver = new ChromeDriver(options);

	}
	/*
	 * public void implicitwait(int i) {
	 * 
	 * driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(i));
	 * 
	 * }
	 */

	public static void takescreenshot(String imageName) throws Exception {

		// Convert web driver object to TakeScreenshot
		scrShot = ((TakesScreenshot) driver);

		// Call getScreenshotAs method to create image file
		File SrcFile = scrShot.getScreenshotAs(OutputType.FILE);

		// Move image file to new destination
		File DestFile = new File("./ScreenShots/" + imageName + "_" + "test.png");

		// Copy file at destination
		FileUtils.copyFile(SrcFile, DestFile);

	}

	public static void extentreportinit() {

		extent = new ExtentReports();
		spark = new ExtentSparkReporter(".//ExtentReport//TestResult.html");
		spark.config().setTheme(Theme.DARK); // for dark theme report
		extent.attachReporter(spark);
		extent.setSystemInfo("OS", "Windows 11");

	}

	public static void extentclose() {

		extent.flush();
	}

	public static void closebrowser() {
		driver.quit();
	}
}