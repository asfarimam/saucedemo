package com.saucelab.TestCases;

import java.io.File;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.saucelab.pageobjectmodel.homepage;
import com.saucelab.pageobjectmodel.loginpage;

public class TestCases extends BaseClass {
	// private static Logger logger;
	loginpage lp = new loginpage();
	homepage hp = new homepage();

	private void extentReport(String nodeName, String testName) {

		BaseClass.exParentTest = BaseClass.extent.createTest(testName);
		BaseClass.exChildTest = BaseClass.exParentTest.createNode(nodeName);
	}

	@BeforeTest

	public void setup() {
		BaseClass.extentreportinit();
		BaseClass.launchbrowser();
		driver.manage().window().maximize();
		// logger = LogManager.getLogger(getClass());

	}

	@AfterTest
	public void tearDown() {
		BaseClass.extentclose();
		BaseClass.closebrowser();
	}

	@DataProvider
	public Object[][] getusernamepass() {

		return new Object[][] { { "standard_user", "secret_sauce" }, { "locked_out_user", "secret_sauce" },
				{ "problem_user", "secret_sauce" }, };
	}

	@Test(priority = 1, dataProvider = "getusernamepass", alwaysRun = false, enabled = false)
	public void multiplelogintest(String username, String password) throws Exception {
		extentReport("Multiple Login", "Test Multiple Login");
		try {
			lp.Login("https://www.saucedemo.com/", username, password);
			String actualUrl = driver.getCurrentUrl();
			String expectedUrl = "https://www.saucedemo.com/inventory.html";
			Assert.assertEquals(actualUrl, expectedUrl);
			BaseClass.takescreenshot("multiplelogintest");
			hp.LogoutUser();
			
			// append screen shot to extent report
			File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			BaseClass.exChildTest.log(Status.PASS, "multiplelogintest - Passed",
			MediaEntityBuilder.createScreenCaptureFromBase64String(screenshotFile.getAbsolutePath()).build());
		} catch (Exception e) {
			System.out.println("Something Went Wrong " + e.getMessage());
			BaseClass.takescreenshot("multiplelogintest");
			BaseClass.exChildTest.log(Status.FAIL, "multiplelogintest - Failed");
			BaseClass.exChildTest.log(Status.INFO, e.getMessage());
		}
	}

	@Test(priority = 2)
	public void logintest() throws Exception {
		extentReport("Valid Login", "Test Valid Login");

		try {
			System.out.println("Something Went Wrong ");
			lp.Login("https://www.saucedemo.com/", "standard_user", "secret_sauce");
			Thread.sleep(2000);
			// verify Login successfull
			// logger.info("Assert Login");

			String actualUrl = driver.getCurrentUrl();
			String expectedUrl = "https://www.saucedemo.com/inventory.html";
			Assert.assertEquals(actualUrl, expectedUrl);
			BaseClass.takescreenshot("logintest");

			Thread.sleep(2000);
			// logout user
			hp.LogoutUser();
			BaseClass.exChildTest.log(Status.PASS, "ValidLoginTest - Passed");
		} catch (AssertionError e) {
			System.out.println("Something Went Wrong " + e.getMessage());
			BaseClass.takescreenshot("logintest");
			BaseClass.exChildTest.log(Status.FAIL, "ValidLoginTest - Failed");
			BaseClass.exChildTest.log(Status.INFO, e.getMessage());
		}
	}

	@Test(priority = 3)
	public void testInvalidLogin() throws Exception {
		extentReport("InValid Login", "Test InValid Login");
		try {
			// Perform an invalid login
			lp.Login("https://www.saucedemo.com/", "standard_user1", "secret_sauce");

			// Assert that an error message is displayed
			String actualtext = lp.getErrorMessage();
			String expectedtext = "Epic sadface: Username and password do not match any user in this service";
			Assert.assertEquals(actualtext, expectedtext);
			BaseClass.takescreenshot("testInvalidLogin");
			BaseClass.exChildTest.log(Status.PASS, "InValidLoginTest - Passed");
		} catch (Exception e) {
			System.out.println("Something Went Wrong " + e);
			BaseClass.takescreenshot("testInvalidLogin");
			BaseClass.exChildTest.log(Status.FAIL, "InValidLoginTest - Failed");
		}
	}

	@Test(priority = 4)
	public void addtocarttest() throws Exception {
		extentReport("Add to Cart", "Test Add To Cart");
		try {
			lp.Login("https://www.saucedemo.com/", "standard_user", "secret_sauce");

			// adding item to cart and validating item is added or not into cart
			hp.addtocart();
			BaseClass.takescreenshot("addtocarttest");
			BaseClass.exChildTest.log(Status.PASS, "addtocarttest - Passed");
			hp.LogoutUser();
		} catch (Exception e) {
			BaseClass.takescreenshot("addtocarttest");
			BaseClass.exChildTest.log(Status.FAIL, "addtocarttest - Failed");
		}
	}
	@Test(priority = 5)
	public void removefromcarttest() throws Exception {
		extentReport("Remove from Cart", "Test Remove from Cart");
		try {
			lp.Login("https://www.saucedemo.com/", "standard_user", "secret_sauce");

			// adding item to cart and validating item is added or not into cart
			hp.addtocart();
			// now removing item from cart
			hp.removefromcart();
			BaseClass.takescreenshot("removefromcarttest");
			BaseClass.exChildTest.log(Status.PASS, "removefromcarttest - Passed");
			hp.LogoutUser();
		} catch (Exception e) {
			BaseClass.takescreenshot("removefromcarttest");
			BaseClass.exChildTest.log(Status.FAIL, "removefromcarttest - Failed");
		}	
	}
	
	@Test(priority = 6)
	public void checkouttest() throws Exception {
		extentReport("Check Out", "Test Check Out");
		try {
			lp.Login("https://www.saucedemo.com/", "standard_user", "secret_sauce");

			// adding item to cart and validating item is added or not into cart
			hp.addtocart();
			// validate cart has item for checkout
			hp.carthasitem();
			// proceed to checkout
			hp.checkout();
			// if above method checkout is passed then now currently standing on overview page
			// print total value
			hp.gettotal();
			// click on finish 
			hp.clickfinish();
			// get success message
			hp.getsuccessMessage();
			Thread.sleep(4000);
			// take successful screenshot
			BaseClass.takescreenshot("checkouttest");
			// logginf to report test is passed
			BaseClass.exChildTest.log(Status.PASS, "checkouttest - Passed");
			
			// navigate back to products
			hp.clickbacktoproduct();
			// logout
			hp.LogoutUser();
		} catch (Exception e) {
			BaseClass.takescreenshot("checkouttest");
			BaseClass.exChildTest.log(Status.FAIL, "checkouttest - Failed");
		}	
	}
}